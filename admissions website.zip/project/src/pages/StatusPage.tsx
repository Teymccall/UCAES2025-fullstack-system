import React from 'react';
import { CheckCircle, Clock, AlertCircle, Download, Eye, FileText } from 'lucide-react';

const StatusPage: React.FC = () => {
  const applicationStatus = {
    id: 'APP-2024-001',
    status: 'under_review',
    submittedDate: '2024-01-15',
    lastUpdated: '2024-01-16',
    program: 'Agricultural Engineering',
    level: 'Undergraduate',
    documents: [
      { name: 'Academic Certificate', status: 'verified', uploadDate: '2024-01-15' },
      { name: 'Transcript', status: 'verified', uploadDate: '2024-01-15' },
      { name: 'ID Document', status: 'verified', uploadDate: '2024-01-15' },
      { name: 'Passport Photo', status: 'verified', uploadDate: '2024-01-15' }
    ]
  };

  const statusTimeline = [
    {
      status: 'Application Submitted',
      date: '2024-01-15',
      completed: true,
      description: 'Your application has been successfully submitted'
    },
    {
      status: 'Payment Confirmed',
      date: '2024-01-15',
      completed: true,
      description: 'Application fee payment received and confirmed'
    },
    {
      status: 'Document Verification',
      date: '2024-01-16',
      completed: true,
      description: 'All uploaded documents have been verified'
    },
    {
      status: 'Application Review',
      date: 'In Progress',
      completed: false,
      current: true,
      description: 'Admissions committee is reviewing your application'
    },
    {
      status: 'Admission Decision',
      date: 'Pending',
      completed: false,
      description: 'Final decision on your application'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'under_review': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'accepted': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'under_review': return <Clock className="h-5 w-5" />;
      case 'accepted': return <CheckCircle className="h-5 w-5" />;
      case 'rejected': return <AlertCircle className="h-5 w-5" />;
      default: return <FileText className="h-5 w-5" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Application Status</h1>
        <p className="text-gray-600">Track the progress of your UCAES application</p>
      </div>

      {/* Status Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Application Overview</h2>
            <p className="text-sm text-gray-600">Application ID: {applicationStatus.id}</p>
          </div>
          <span className={`inline-flex items-center px-3 py-2 rounded-lg text-sm font-medium border ${getStatusColor(applicationStatus.status)}`}>
            {getStatusIcon(applicationStatus.status)}
            <span className="ml-2 capitalize">{applicationStatus.status.replace('_', ' ')}</span>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900">Program</h3>
            <p className="text-lg font-semibold text-gray-700">{applicationStatus.program}</p>
            <p className="text-sm text-gray-600">{applicationStatus.level}</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900">Submitted</h3>
            <p className="text-lg font-semibold text-gray-700">{applicationStatus.submittedDate}</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900">Last Updated</h3>
            <p className="text-lg font-semibold text-gray-700">{applicationStatus.lastUpdated}</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900">Documents</h3>
            <p className="text-lg font-semibold text-green-600">All Verified</p>
          </div>
        </div>
      </div>

      {/* Application Timeline */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-6">Application Timeline</h2>
        
        <div className="space-y-6">
          {statusTimeline.map((item, index) => (
            <div key={index} className="flex items-start">
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                item.completed 
                  ? 'bg-green-600' 
                  : item.current 
                  ? 'bg-yellow-500' 
                  : 'bg-gray-300'
              }`}>
                {item.completed ? (
                  <CheckCircle className="h-5 w-5 text-white" />
                ) : item.current ? (
                  <Clock className="h-5 w-5 text-white" />
                ) : (
                  <div className="w-3 h-3 bg-white rounded-full"></div>
                )}
              </div>
              
              <div className="ml-4 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className={`text-sm font-medium ${
                    item.completed || item.current ? 'text-gray-900' : 'text-gray-500'
                  }`}>
                    {item.status}
                  </h3>
                  <span className={`text-sm ${
                    item.completed || item.current ? 'text-gray-600' : 'text-gray-400'
                  }`}>
                    {item.date}
                  </span>
                </div>
                <p className={`text-sm mt-1 ${
                  item.completed || item.current ? 'text-gray-600' : 'text-gray-400'
                }`}>
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Document Status */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Document Verification Status</h2>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Document</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Upload Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Action</th>
              </tr>
            </thead>
            <tbody>
              {applicationStatus.documents.map((doc, index) => (
                <tr key={index} className="border-b border-gray-100">
                  <td className="py-3 px-4 text-gray-900">{doc.name}</td>
                  <td className="py-3 px-4 text-gray-600">{doc.uploadDate}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      doc.status === 'verified' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {doc.status === 'verified' && <CheckCircle className="h-3 w-3 mr-1" />}
                      {doc.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button className="text-green-600 hover:text-green-700 text-sm flex items-center">
                      <Eye className="h-4 w-4 mr-1" />
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Next Steps */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">What's Next?</h2>
        
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-900">Current Status: Under Review</h3>
            <p className="text-sm text-blue-800 mt-1">
              Your application is currently being reviewed by our admissions committee. 
              This process typically takes 2-4 weeks.
            </p>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-yellow-900">Expected Timeline</h3>
            <p className="text-sm text-yellow-800 mt-1">
              Admission decisions will be communicated by March 15, 2024. 
              You will receive an email notification once a decision is made.
            </p>
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-green-900">Need Help?</h3>
            <p className="text-sm text-green-800 mt-1">
              If you have any questions about your application status, contact our admissions office at 
              <span className="font-medium"> admissions@ucaes.edu.gh</span> or 
              <span className="font-medium"> +233 30 123 4567</span>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusPage;