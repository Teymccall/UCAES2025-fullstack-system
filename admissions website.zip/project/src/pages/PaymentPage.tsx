import React, { useState } from 'react';
import { CreditCard, Smartphone, Receipt, CheckCircle, AlertCircle } from 'lucide-react';

const PaymentPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'current' | 'history'>('current');
  const [paymentStatus] = useState<'pending' | 'paid' | 'failed'>('paid');

  const paymentHistory = [
    {
      id: 'PAY-2024-001',
      date: '2024-01-15',
      amount: 150,
      description: 'Application Fee',
      status: 'paid',
      method: 'Mobile Money'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Payment Center</h1>
        <p className="text-gray-600">Manage your application payments and view transaction history</p>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('current')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'current'
                ? 'border-green-500 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Current Payment
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'history'
                ? 'border-green-500 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Payment History
          </button>
        </nav>
      </div>

      {activeTab === 'current' && (
        <div className="space-y-6">
          {/* Current Payment Status */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Application Fee</h2>
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                paymentStatus === 'paid' 
                  ? 'bg-green-100 text-green-800'
                  : paymentStatus === 'pending'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {paymentStatus === 'paid' && <CheckCircle className="h-4 w-4 mr-1" />}
                {paymentStatus === 'failed' && <AlertCircle className="h-4 w-4 mr-1" />}
                {paymentStatus.charAt(0).toUpperCase() + paymentStatus.slice(1)}
              </span>
            </div>

            {paymentStatus === 'paid' ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-green-900">Payment Successful</h3>
                    <p className="text-green-800">Your application fee has been paid successfully.</p>
                  </div>
                </div>
                
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-green-900">Amount Paid</label>
                    <p className="text-lg font-semibold text-green-800">GHS 150.00</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-green-900">Payment Date</label>
                    <p className="text-lg font-semibold text-green-800">January 15, 2024</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-green-900">Transaction ID</label>
                    <p className="text-lg font-semibold text-green-800">PAY-2024-001</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-green-900">Payment Method</label>
                    <p className="text-lg font-semibold text-green-800">Mobile Money</p>
                  </div>
                </div>

                <div className="mt-4">
                  <button className="inline-flex items-center px-4 py-2 border border-green-600 text-sm font-medium rounded-md text-green-600 bg-white hover:bg-green-50">
                    <Receipt className="h-4 w-4 mr-2" />
                    Download Receipt
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-medium text-blue-900">Application Fee</h3>
                      <p className="text-sm text-blue-800">One-time payment to process your application</p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-blue-900">GHS 150</div>
                      <div className="text-sm text-blue-800">Non-refundable</div>
                    </div>
                  </div>
                </div>

                {/* Payment Methods */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Choose Payment Method</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border-2 border-gray-300 rounded-lg p-4 hover:border-green-400 cursor-pointer transition-colors">
                      <div className="flex items-center space-x-3">
                        <Smartphone className="h-8 w-8 text-green-600" />
                        <div>
                          <h4 className="font-medium text-gray-900">Mobile Money</h4>
                          <p className="text-sm text-gray-600">MTN, Vodafone, AirtelTigo</p>
                        </div>
                      </div>
                    </div>

                    <div className="border-2 border-gray-300 rounded-lg p-4 hover:border-green-400 cursor-pointer transition-colors">
                      <div className="flex items-center space-x-3">
                        <CreditCard className="h-8 w-8 text-green-600" />
                        <div>
                          <h4 className="font-medium text-gray-900">Card Payment</h4>
                          <p className="text-sm text-gray-600">Visa, Mastercard</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-yellow-900">Important Note</h3>
                  <p className="text-sm text-yellow-800 mt-1">
                    Payment must be completed before your application can be reviewed. 
                    Keep your payment receipt for your records.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Payment History</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Transaction ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {paymentHistory.map((payment) => (
                  <tr key={payment.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {payment.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {payment.date}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {payment.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      GHS {payment.amount}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {payment.method}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        payment.status === 'paid' 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {payment.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button className="text-green-600 hover:text-green-900">
                        Download
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentPage;