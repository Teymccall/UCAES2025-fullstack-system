import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import ApplicantDashboard from '../components/Dashboard/ApplicantDashboard';
import StaffDashboard from './StaffDashboard';
import AdminDashboard from './AdminDashboard';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  if (user?.role === 'admin') {
    return <AdminDashboard />;
  }

  if (user?.role === 'staff') {
    return <StaffDashboard />;
  }

  return <ApplicantDashboard />;
};

export default Dashboard;