import React, { useState, useEffect } from 'react';
import { useApplication } from '../../contexts/ApplicationContext';
import { GraduationCap, Plus, Trash2, Upload } from 'lucide-react';

const AcademicBackgroundForm: React.FC = () => {
  const { applicationData, updateAcademicBackground, setCurrentStep } = useApplication();
  const [formData, setFormData] = useState(applicationData.academicBackground);

  useEffect(() => {
    setFormData(applicationData.academicBackground);
  }, [applicationData.academicBackground]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const addSubject = () => {
    setFormData(prev => ({
      ...prev,
      subjects: [...prev.subjects, { subject: '', grade: '' }]
    }));
  };

  const removeSubject = (index: number) => {
    setFormData(prev => ({
      ...prev,
      subjects: prev.subjects.filter((_, i) => i !== index)
    }));
  };

  const updateSubject = (index: number, field: 'subject' | 'grade', value: string) => {
    setFormData(prev => ({
      ...prev,
      subjects: prev.subjects.map((subject, i) => 
        i === index ? { ...subject, [field]: value } : subject
      )
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setFormData(prev => ({
      ...prev,
      certificates: files
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateAcademicBackground(formData);
    setCurrentStep(4);
  };

  const handlePrevious = () => {
    updateAcademicBackground(formData);
    setCurrentStep(2);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <GraduationCap className="h-6 w-6 text-green-600" />
          <h2 className="text-xl font-semibold text-gray-900">Academic Background</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="schoolName" className="block text-sm font-medium text-gray-700">
                School/Institution Name *
              </label>
              <input
                type="text"
                id="schoolName"
                name="schoolName"
                required
                value={formData.schoolName}
                onChange={handleChange}
                placeholder="Name of your last school"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            <div>
              <label htmlFor="qualificationType" className="block text-sm font-medium text-gray-700">
                Qualification Type *
              </label>
              <select
                id="qualificationType"
                name="qualificationType"
                required
                value={formData.qualificationType}
                onChange={handleChange}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                <option value="">Select Qualification</option>
                <option value="wassce">WASSCE</option>
                <option value="ssce">SSCE</option>
                <option value="novdec">Nov/Dec</option>
                <option value="diploma">Diploma</option>
                <option value="hnd">HND</option>
                <option value="degree">Bachelor's Degree</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label htmlFor="yearCompleted" className="block text-sm font-medium text-gray-700">
                Year Completed *
              </label>
              <input
                type="number"
                id="yearCompleted"
                name="yearCompleted"
                required
                min="1980"
                max="2024"
                value={formData.yearCompleted}
                onChange={handleChange}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">Subject Results</h3>
              <button
                type="button"
                onClick={addSubject}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Subject
              </button>
            </div>

            <div className="space-y-3">
              {formData.subjects.map((subject, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      placeholder="Subject name"
                      value={subject.subject}
                      onChange={(e) => updateSubject(index, 'subject', e.target.value)}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div className="w-24">
                    <select
                      value={subject.grade}
                      onChange={(e) => updateSubject(index, 'grade', e.target.value)}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                    >
                      <option value="">Grade</option>
                      <option value="A1">A1</option>
                      <option value="B2">B2</option>
                      <option value="B3">B3</option>
                      <option value="C4">C4</option>
                      <option value="C5">C5</option>
                      <option value="C6">C6</option>
                      <option value="D7">D7</option>
                      <option value="E8">E8</option>
                      <option value="F9">F9</option>
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeSubject(index)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Upload Certificates/Transcripts
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor="certificates"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-green-600 hover:text-green-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-green-500"
                  >
                    <span>Upload files</span>
                    <input
                      id="certificates"
                      name="certificates"
                      type="file"
                      multiple
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileChange}
                      className="sr-only"
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">
                  PDF, PNG, JPG up to 10MB each
                </p>
              </div>
            </div>
            {formData.certificates && formData.certificates.length > 0 && (
              <div className="mt-2">
                <p className="text-sm text-gray-600">
                  {formData.certificates.length} file(s) selected
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-between">
            <button
              type="button"
              onClick={handlePrevious}
              className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
            >
              Previous
            </button>
            <button
              type="submit"
              className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
            >
              Next: Program Selection
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AcademicBackgroundForm;