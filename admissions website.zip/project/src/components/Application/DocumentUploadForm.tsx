import React, { useState, useEffect } from 'react';
import { useApplication } from '../../contexts/ApplicationContext';
import { Upload, FileText, CheckCircle } from 'lucide-react';

const DocumentUploadForm: React.FC = () => {
  const { applicationData, updateDocuments, setCurrentStep } = useApplication();
  const [documents, setDocuments] = useState(applicationData.documents);

  useEffect(() => {
    setDocuments(applicationData.documents);
  }, [applicationData.documents]);

  const handleFileChange = (documentType: keyof typeof documents) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDocuments(prev => ({
        ...prev,
        [documentType]: file
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateDocuments(documents);
    setCurrentStep(6);
  };

  const handlePrevious = () => {
    updateDocuments(documents);
    setCurrentStep(4);
  };

  const DocumentUploadBox: React.FC<{
    title: string;
    description: string;
    documentType: keyof typeof documents;
    required?: boolean;
  }> = ({ title, description, documentType, required = false }) => {
    const file = documents[documentType];
    
    return (
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-green-400 transition-colors">
        <div className="text-center">
          <div className="flex justify-center mb-3">
            {file ? (
              <CheckCircle className="h-12 w-12 text-green-600" />
            ) : (
              <Upload className="h-12 w-12 text-gray-400" />
            )}
          </div>
          
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {title} {required && <span className="text-red-500">*</span>}
          </h3>
          
          <p className="text-sm text-gray-600 mb-4">{description}</p>
          
          {file ? (
            <div className="space-y-2">
              <p className="text-sm text-green-600 font-medium">
                ✓ {file.name}
              </p>
              <label
                htmlFor={documentType}
                className="inline-flex items-center px-4 py-2 border border-green-600 text-sm font-medium rounded-md text-green-600 bg-white hover:bg-green-50 cursor-pointer"
              >
                Change File
              </label>
            </div>
          ) : (
            <label
              htmlFor={documentType}
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
            >
              <Upload className="h-4 w-4 mr-2" />
              Choose File
            </label>
          )}
          
          <input
            id={documentType}
            type="file"
            accept=".pdf,.jpg,.jpeg,.png"
            onChange={handleFileChange(documentType)}
            className="hidden"
          />
          
          <p className="text-xs text-gray-500 mt-2">
            PDF, JPG, PNG (Max: 5MB)
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <FileText className="h-6 w-6 text-green-600" />
          <h2 className="text-xl font-semibold text-gray-900">Document Upload</h2>
        </div>

        <div className="mb-6 bg-blue-50 border border-blue-200 rounded-md p-4">
          <h3 className="text-sm font-medium text-blue-900 mb-2">Important Notes:</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• All documents must be clear and legible</li>
            <li>• Accepted formats: PDF, JPG, PNG</li>
            <li>• Maximum file size: 5MB per document</li>
            <li>• Required documents must be uploaded to proceed</li>
          </ul>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <DocumentUploadBox
              title="Passport Photo"
              description="Recent passport-sized photograph with white background"
              documentType="photo"
              required
            />
            
            <DocumentUploadBox
              title="National ID/Passport"
              description="Valid government-issued identification document"
              documentType="idDocument"
              required
            />
            
            <DocumentUploadBox
              title="Academic Certificate"
              description="Latest academic qualification certificate"
              documentType="certificate"
              required
            />
            
            <DocumentUploadBox
              title="Academic Transcript"
              description="Official transcript of academic records"
              documentType="transcript"
              required
            />
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
            <h3 className="text-sm font-medium text-yellow-900 mb-2">Document Verification:</h3>
            <p className="text-sm text-yellow-800">
              Uploaded documents will be verified by our admissions team. Please ensure all documents 
              are authentic and belong to you. Any false or misleading information may result in 
              application rejection.
            </p>
          </div>

          <div className="flex justify-between">
            <button
              type="button"
              onClick={handlePrevious}
              className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
            >
              Previous
            </button>
            <button
              type="submit"
              className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
            >
              Next: Payment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DocumentUploadForm;