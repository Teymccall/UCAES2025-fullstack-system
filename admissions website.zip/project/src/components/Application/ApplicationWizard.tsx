import React from 'react';
import { useApplication } from '../../contexts/ApplicationContext';
import PersonalInfoForm from './PersonalInfoForm';
import ContactInfoForm from './ContactInfoForm';
import AcademicBackgroundForm from './AcademicBackgroundForm';
import ProgramSelectionForm from './ProgramSelectionForm';
import DocumentUploadForm from './DocumentUploadForm';
import PaymentForm from './PaymentForm';
import ApplicationSummary from './ApplicationSummary';
import { CheckCircle, Circle } from 'lucide-react';

const ApplicationWizard: React.FC = () => {
  const { currentStep } = useApplication();

  const steps = [
    { id: 1, title: 'Personal Info', component: PersonalInfoForm },
    { id: 2, title: 'Contact Info', component: ContactInfoForm },
    { id: 3, title: 'Academic Background', component: AcademicBackgroundForm },
    { id: 4, title: 'Program Selection', component: ProgramSelectionForm },
    { id: 5, title: 'Documents', component: DocumentUploadForm },
    { id: 6, title: 'Payment', component: PaymentForm },
    { id: 7, title: 'Summary', component: ApplicationSummary }
  ];

  const CurrentStepComponent = steps.find(step => step.id === currentStep)?.component || PersonalInfoForm;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Progress Indicator */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className="flex items-center">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    currentStep > step.id
                      ? 'bg-green-600 border-green-600 text-white'
                      : currentStep === step.id
                      ? 'border-green-600 text-green-600'
                      : 'border-gray-300 text-gray-300'
                  }`}
                >
                  {currentStep > step.id ? (
                    <CheckCircle className="h-6 w-6" />
                  ) : (
                    <span className="text-sm font-medium">{step.id}</span>
                  )}
                </div>
                <div className="ml-3 hidden sm:block">
                  <p
                    className={`text-sm font-medium ${
                      currentStep >= step.id ? 'text-green-600' : 'text-gray-500'
                    }`}
                  >
                    {step.title}
                  </p>
                </div>
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`hidden sm:block w-12 h-0.5 ml-4 ${
                    currentStep > step.id ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Current Step Content */}
      <CurrentStepComponent />
    </div>
  );
};

export default ApplicationWizard;