import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  FileText, 
  Users, 
  Settings, 
  BarChart3, 
  DollarSign,
  CheckCircle,
  Clock
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Sidebar: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();

  const applicantMenuItems = [
    { icon: Home, label: 'Dashboard', path: '/dashboard' },
    { icon: FileText, label: 'Application', path: '/application' },
    { icon: DollarSign, label: 'Payment', path: '/payment' },
    { icon: CheckCircle, label: 'Status', path: '/status' }
  ];

  const staffMenuItems = [
    { icon: Home, label: 'Dashboard', path: '/staff/dashboard' },
    { icon: FileText, label: 'Applications', path: '/staff/applications' },
    { icon: Users, label: 'Applicants', path: '/staff/applicants' },
    { icon: BarChart3, label: 'Reports', path: '/staff/reports' }
  ];

  const adminMenuItems = [
    { icon: Home, label: 'Dashboard', path: '/admin/dashboard' },
    { icon: Users, label: 'Staff Management', path: '/admin/staff' },
    { icon: Settings, label: 'System Settings', path: '/admin/settings' },
    { icon: BarChart3, label: 'Analytics', path: '/admin/analytics' },
    { icon: Clock, label: 'Deadlines', path: '/admin/deadlines' }
  ];

  const getMenuItems = () => {
    if (user?.role === 'admin') return adminMenuItems;
    if (user?.role === 'staff') return staffMenuItems;
    return applicantMenuItems;
  };

  const menuItems = getMenuItems();

  return (
    <div className="w-64 bg-white h-full shadow-sm border-r border-green-100">
      <div className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 capitalize">
          {user?.role} Portal
        </h2>
      </div>
      
      <nav className="mt-6">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-3 px-6 py-3 text-sm font-medium transition-colors duration-200 ${
                isActive
                  ? 'bg-green-50 text-green-700 border-r-2 border-green-600'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default Sidebar;