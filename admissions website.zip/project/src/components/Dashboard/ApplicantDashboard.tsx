import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  FileText, 
  DollarSign, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Download,
  User,
  BookOpen
} from 'lucide-react';

const ApplicantDashboard: React.FC = () => {
  const { user } = useAuth();

  // Mock application data - in real app this would come from an API
  const applicationStatus = {
    status: 'under_review',
    submissionDate: '2024-01-15',
    paymentStatus: 'paid',
    documentsVerified: true,
    applicationId: user?.applicationId || 'APP-2024-001'
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'under_review': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted': return <FileText className="h-5 w-5" />;
      case 'under_review': return <Clock className="h-5 w-5" />;
      case 'accepted': return <CheckCircle className="h-5 w-5" />;
      case 'rejected': return <AlertCircle className="h-5 w-5" />;
      default: return <FileText className="h-5 w-5" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}</h1>
        <p className="text-gray-600">Track your application progress and manage your admission journey.</p>
      </div>

      {/* Application Status Card */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Application Status</h2>
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(applicationStatus.status)}`}>
            {getStatusIcon(applicationStatus.status)}
            <span className="ml-1 capitalize">{applicationStatus.status.replace('_', ' ')}</span>
          </span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-900">{applicationStatus.applicationId}</div>
            <div className="text-sm text-gray-600">Application ID</div>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-900">{applicationStatus.submissionDate}</div>
            <div className="text-sm text-gray-600">Submitted</div>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className={`text-2xl font-bold ${applicationStatus.paymentStatus === 'paid' ? 'text-green-600' : 'text-red-600'}`}>
              {applicationStatus.paymentStatus === 'paid' ? '✓' : '✗'}
            </div>
            <div className="text-sm text-gray-600">Payment</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Link
          to="/application"
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <FileText className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">My Application</h3>
              <p className="text-sm text-gray-600">View and edit application</p>
            </div>
          </div>
        </Link>

        <Link
          to="/payment"
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">Payment</h3>
              <p className="text-sm text-gray-600">Manage payments</p>
            </div>
          </div>
        </Link>

        <Link
          to="/status"
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">Status</h3>
              <p className="text-sm text-gray-600">Track progress</p>
            </div>
          </div>
        </Link>

        <button className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow text-left">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Download className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">Documents</h3>
              <p className="text-sm text-gray-600">Download forms</p>
            </div>
          </div>
        </button>
      </div>

      {/* Application Progress */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Application Progress</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <div className="flex-shrink-0 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-white" />
            </div>
            <div className="ml-4 flex-1">
              <h3 className="text-sm font-medium text-gray-900">Application Submitted</h3>
              <p className="text-sm text-gray-600">Your application has been successfully submitted</p>
            </div>
            <div className="text-sm text-gray-500">{applicationStatus.submissionDate}</div>
          </div>
          
          <div className="flex items-center">
            <div className="flex-shrink-0 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-white" />
            </div>
            <div className="ml-4 flex-1">
              <h3 className="text-sm font-medium text-gray-900">Payment Confirmed</h3>
              <p className="text-sm text-gray-600">Application fee payment received</p>
            </div>
            <div className="text-sm text-gray-500">Jan 15, 2024</div>
          </div>
          
          <div className="flex items-center">
            <div className="flex-shrink-0 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
              <Clock className="h-5 w-5 text-white" />
            </div>
            <div className="ml-4 flex-1">
              <h3 className="text-sm font-medium text-gray-900">Under Review</h3>
              <p className="text-sm text-gray-600">Admissions team is reviewing your application</p>
            </div>
            <div className="text-sm text-gray-500">In Progress</div>
          </div>
          
          <div className="flex items-center">
            <div className="flex-shrink-0 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <Clock className="h-5 w-5 text-white" />
            </div>
            <div className="ml-4 flex-1">
              <h3 className="text-sm font-medium text-gray-500">Admission Decision</h3>
              <p className="text-sm text-gray-400">Final decision on your application</p>
            </div>
            <div className="text-sm text-gray-400">Pending</div>
          </div>
        </div>
      </div>

      {/* Recent Activity & Important Information */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <User className="h-5 w-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm text-gray-900">Application submitted successfully</p>
                <p className="text-xs text-gray-500">2 days ago</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <DollarSign className="h-5 w-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm text-gray-900">Payment of GHS 150 confirmed</p>
                <p className="text-xs text-gray-500">2 days ago</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <FileText className="h-5 w-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm text-gray-900">Documents uploaded and verified</p>
                <p className="text-xs text-gray-500">3 days ago</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Important Information</h2>
          <div className="space-y-3">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <h3 className="text-sm font-medium text-blue-900">Admission Timeline</h3>
              <p className="text-sm text-blue-800 mt-1">
                Results will be published by March 15, 2024
              </p>
            </div>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <h3 className="text-sm font-medium text-yellow-900">Document Verification</h3>
              <p className="text-sm text-yellow-800 mt-1">
                Original documents must be presented during registration
              </p>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <h3 className="text-sm font-medium text-green-900">Contact Support</h3>
              <p className="text-sm text-green-800 mt-1">
                Email: admissions@ucaes.edu.gh | Phone: +233 30 123 4567
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicantDashboard;