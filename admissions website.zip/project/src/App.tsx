import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ApplicationProvider } from './contexts/ApplicationContext';
import LandingPage from './pages/LandingPage';
import LoginForm from './components/Auth/LoginForm';
import RegisterForm from './components/Auth/RegisterForm';
import Dashboard from './pages/Dashboard';
import ApplicationPage from './pages/ApplicationPage';
import PaymentPage from './pages/PaymentPage';
import StatusPage from './pages/StatusPage';
import StaffDashboard from './pages/StaffDashboard';
import StaffApplications from './pages/StaffApplications';
import StaffApplicants from './pages/StaffApplicants';
import StaffReports from './pages/StaffReports';
import AdminDashboard from './pages/AdminDashboard';
import AdminStaff from './pages/AdminStaff';
import AdminSettings from './pages/AdminSettings';
import AdminAnalytics from './pages/AdminAnalytics';
import AdminDeadlines from './pages/AdminDeadlines';
import Header from './components/Layout/Header';
import Sidebar from './components/Layout/Sidebar';

const PrivateRoute: React.FC<{ children: React.ReactNode; roles?: string[] }> = ({ children, roles }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/dashboard" />;
  }

  return <>{children}</>;
};

const AppContent: React.FC = () => {
  const { user } = useAuth();

  const isAuthPage = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/';

  if (isAuthPage || !user) {
    return (
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/register" element={<RegisterForm />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <Routes>
            <Route path="/dashboard" element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            } />
            <Route path="/application" element={
              <PrivateRoute roles={['applicant']}>
                <ApplicationProvider>
                  <ApplicationPage />
                </ApplicationProvider>
              </PrivateRoute>
            } />
            <Route path="/payment" element={
              <PrivateRoute roles={['applicant']}>
                <PaymentPage />
              </PrivateRoute>
            } />
            <Route path="/status" element={
              <PrivateRoute roles={['applicant']}>
                <StatusPage />
              </PrivateRoute>
            } />
            
            {/* Staff Routes */}
            <Route path="/staff/dashboard" element={
              <PrivateRoute roles={['staff', 'admin']}>
                <StaffDashboard />
              </PrivateRoute>
            } />
            <Route path="/staff/applications" element={
              <PrivateRoute roles={['staff', 'admin']}>
                <StaffApplications />
              </PrivateRoute>
            } />
            <Route path="/staff/applicants" element={
              <PrivateRoute roles={['staff', 'admin']}>
                <StaffApplicants />
              </PrivateRoute>
            } />
            <Route path="/staff/reports" element={
              <PrivateRoute roles={['staff', 'admin']}>
                <StaffReports />
              </PrivateRoute>
            } />
            
            {/* Admin Routes */}
            <Route path="/admin/dashboard" element={
              <PrivateRoute roles={['admin']}>
                <AdminDashboard />
              </PrivateRoute>
            } />
            <Route path="/admin/staff" element={
              <PrivateRoute roles={['admin']}>
                <AdminStaff />
              </PrivateRoute>
            } />
            <Route path="/admin/settings" element={
              <PrivateRoute roles={['admin']}>
                <AdminSettings />
              </PrivateRoute>
            } />
            <Route path="/admin/analytics" element={
              <PrivateRoute roles={['admin']}>
                <AdminAnalytics />
              </PrivateRoute>
            } />
            <Route path="/admin/deadlines" element={
              <PrivateRoute roles={['admin']}>
                <AdminDeadlines />
              </PrivateRoute>
            } />
            
            <Route path="*" element={<Navigate to="/dashboard" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;