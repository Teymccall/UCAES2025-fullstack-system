import React, { createContext, useContext, useState } from 'react';

interface PersonalInfo {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  nationality: string;
  region: string;
  photo?: File;
}

interface ContactInfo {
  phone: string;
  email: string;
  address: string;
  emergencyContact: string;
  emergencyPhone: string;
}

interface AcademicBackground {
  schoolName: string;
  qualificationType: string;
  yearCompleted: string;
  subjects: Array<{ subject: string; grade: string }>;
  certificates?: File[];
}

interface ProgramSelection {
  program: string;
  level: string;
  studyMode: string;
  firstChoice: string;
  secondChoice: string;
}

interface DocumentUploads {
  photo?: File;
  idDocument?: File;
  certificate?: File;
  transcript?: File;
}

interface ApplicationData {
  personalInfo: PersonalInfo;
  contactInfo: ContactInfo;
  academicBackground: AcademicBackground;
  programSelection: ProgramSelection;
  documents: DocumentUploads;
  paymentStatus: 'pending' | 'paid' | 'failed';
  applicationStatus: 'draft' | 'submitted' | 'under_review' | 'accepted' | 'rejected';
}

interface ApplicationContextType {
  applicationData: ApplicationData;
  updatePersonalInfo: (data: PersonalInfo) => void;
  updateContactInfo: (data: ContactInfo) => void;
  updateAcademicBackground: (data: AcademicBackground) => void;
  updateProgramSelection: (data: ProgramSelection) => void;
  updateDocuments: (data: DocumentUploads) => void;
  updatePaymentStatus: (status: 'pending' | 'paid' | 'failed') => void;
  submitApplication: () => void;
  currentStep: number;
  setCurrentStep: (step: number) => void;
}

const ApplicationContext = createContext<ApplicationContextType | undefined>(undefined);

export const useApplication = () => {
  const context = useContext(ApplicationContext);
  if (context === undefined) {
    throw new Error('useApplication must be used within an ApplicationProvider');
  }
  return context;
};

const initialApplicationData: ApplicationData = {
  personalInfo: {
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    nationality: '',
    region: ''
  },
  contactInfo: {
    phone: '',
    email: '',
    address: '',
    emergencyContact: '',
    emergencyPhone: ''
  },
  academicBackground: {
    schoolName: '',
    qualificationType: '',
    yearCompleted: '',
    subjects: []
  },
  programSelection: {
    program: '',
    level: '',
    studyMode: '',
    firstChoice: '',
    secondChoice: ''
  },
  documents: {},
  paymentStatus: 'pending',
  applicationStatus: 'draft'
};

export const ApplicationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [applicationData, setApplicationData] = useState<ApplicationData>(initialApplicationData);
  const [currentStep, setCurrentStep] = useState(1);

  const updatePersonalInfo = (data: PersonalInfo) => {
    setApplicationData(prev => ({ ...prev, personalInfo: data }));
  };

  const updateContactInfo = (data: ContactInfo) => {
    setApplicationData(prev => ({ ...prev, contactInfo: data }));
  };

  const updateAcademicBackground = (data: AcademicBackground) => {
    setApplicationData(prev => ({ ...prev, academicBackground: data }));
  };

  const updateProgramSelection = (data: ProgramSelection) => {
    setApplicationData(prev => ({ ...prev, programSelection: data }));
  };

  const updateDocuments = (data: DocumentUploads) => {
    setApplicationData(prev => ({ ...prev, documents: data }));
  };

  const updatePaymentStatus = (status: 'pending' | 'paid' | 'failed') => {
    setApplicationData(prev => ({ ...prev, paymentStatus: status }));
  };

  const submitApplication = () => {
    setApplicationData(prev => ({ ...prev, applicationStatus: 'submitted' }));
  };

  return (
    <ApplicationContext.Provider value={{
      applicationData,
      updatePersonalInfo,
      updateContactInfo,
      updateAcademicBackground,
      updateProgramSelection,
      updateDocuments,
      updatePaymentStatus,
      submitApplication,
      currentStep,
      setCurrentStep
    }}>
      {children}
    </ApplicationContext.Provider>
  );
};